from django.apps import AppConfig


class DeliverytrackConfig(AppConfig):
    name = 'deliverytrack'
