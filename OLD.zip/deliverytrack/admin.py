from django.contrib import admin
from .models import AcceptOrderRequest

admin.site.register(AcceptOrderRequest)