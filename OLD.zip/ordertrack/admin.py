from django.contrib import admin
from .models import PostOrderRequest

admin.site.register(PostOrderRequest)
