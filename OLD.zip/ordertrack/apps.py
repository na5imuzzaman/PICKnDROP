from django.apps import AppConfig


class OrdertrackConfig(AppConfig):
    name = 'ordertrack'
