CHOICES_PickupPoint = (
    ('Khagan', 'Khagan'),
    ('Charabag', 'Charabag'),
    ('Savar', 'Savar'),
    ('Mirpir-1','Mirpur-1'),
    ('New Market','New Market'),
    ('Nilkhet','Nilkhet'),
    ('Panthopath','Panthopath'),
    ('Shahbagh','Shahbagh'),
    ('Gulistan','Gulistan'),
    ('Uttara','Uttara'),
    ('Airport','Airport'),
    ('Dhanmondi','Dhanmondi'),
    ('Shyamoli','Shyamoli'),
    ('IDB', 'IDB'),
)
CHOICES_PickupPointType = (
    ('Shop', 'Shop'),
    ('Home', 'Home'),
    ('Office', 'Office'),
    ('Inperson', 'Inperson'),
)

CHOICES_ParcelType = (
    ('Documents', 'Documents'),
    ('Medicine', 'Medicine'),
    ('Electronics', 'Electronics'),
    ('Books','Books'),
    ('Clothes','Clothes'),
    ('Food','Food'),
    ('Accessories','Accessories'),
    ('Others', 'Others')
)

CHOICES_HallName = (
    ('YKSG East', 'YKSG East'),
    ('YKSG West', 'YKSG West'),
    ('YKSG New Buliding', 'YKSG New Building'),
    ('YKSG Extension 1', 'YKSG Extension 1'),
)