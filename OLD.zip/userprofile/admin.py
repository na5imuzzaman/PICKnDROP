from django.contrib import admin
from .models import ProfileEdit


admin.site.register(ProfileEdit)