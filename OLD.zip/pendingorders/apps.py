from django.apps import AppConfig


class PendingordersConfig(AppConfig):
    name = 'pendingorders'
