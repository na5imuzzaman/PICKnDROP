from django.urls import path
from pendingorders import views as pv


urlpatterns = [
]