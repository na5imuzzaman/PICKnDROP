from django.apps import AppConfig


class HomeonlyConfig(AppConfig):
    name = 'homeonly'
